show databases;
drop schema my_database;
CREATE DATABASE my_database;
show tables;
USE my_database;
select database();

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    password VARCHAR(255) NOT NULL
);
INSERT INTO users (username, email, phone, password) VALUES ('camilo', 'efigueroa@gmail.com', '312245204', '485200');
select * from users;



CREATE TABLE users1 (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    -- otras columnas
    UNIQUE KEY (email)
);

select*from users1;

CREATE TABLE password_resets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    token VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
-- Asociación de reseteo de contraseña para usuario1
INSERT INTO password_resets (user_id, token, created_at)
VALUES (1, 'token_usuario1', NOW());

-- Asociación de reseteo de contraseña para usuario2
INSERT INTO password_resets (user_id, token, created_at)
VALUES (2, 'token_usuario2', NOW());

-- Asociación de reseteo de contraseña para usuario3
INSERT INTO password_resets (user_id, token, created_at)
VALUES (3, 'token_usuario3', NOW());

CREATE TABLE inicios_sesion (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    hora_inicio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES users(id) ON DELETE CASCADE
);











