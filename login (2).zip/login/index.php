<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login y Registro</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <div class="form-container">
            <form id="loginForm" class="form hidden" method="POST" action="login.php">
                <h2>Iniciar Sesión</h2>
                <label for="loginEmail">Correo Electrónico</label>
                <input type="email" id="loginEmail" placeholder="Ingresa tu correo electrónico" required>
                <label for="loginPassword">Contraseña</label>
                <div class="password-container">
                    <input type="password" id="loginPassword" placeholder="Ingresa tu contraseña" required>
                    <button type="button" id="loginToggle" class="toggle-btn" onclick="togglePassword('loginPassword', 'loginToggle')">Mostrar</button>
                </div>
                <button type="submit">Iniciar Sesión</button>
                <p>¿No tienes una cuenta? <a href="#" id="showRegisterForm">Registrarse</a></p>
                <p><a href="#" id="forgotPassword">Olvidé mi contraseña</a></p>
            </form>
            <form id="registerForm" class="form hidden" method="POST" action="register.php">
                <h2>Registrarse</h2>
                <label for="registerUsername">Nombre de Usuario</label>
                <input type="text" id="registerUsername" name="username" placeholder="Ingresa tu nombre de usuario" required>
                <label for="registerEmail">Correo Electrónico</label>
                <input type="email" id="registerEmail" name="email" placeholder="Ingresa tu correo electrónico" required>
                <label for="registerPhone">Teléfono</label>
                <input type="tel" id="registerPhone" name="phone" placeholder="Ingresa tu número de teléfono" required>
                <label for="registerPassword">Contraseña</label>
                <div class="password-container">
                    <input type="password" id="registerPassword" name="password" placeholder="Ingresa tu contraseña" required>
                    <button type="button" id="registerToggle" class="toggle-btn" onclick="togglePassword('registerPassword', 'registerToggle')">Mostrar</button>
                </div>
                <label for="registerConfirmPassword">Confirmar Contraseña</label>
                <div class="password-container">
                    <input type="password" id="registerConfirmPassword" name="confirm_password" placeholder="Confirma tu contraseña" required>
                    <button type="button" id="confirmToggle" class="toggle-btn" onclick="togglePassword('registerConfirmPassword', 'confirmToggle')">Mostrar</button>
                </div>
                <button type="submit">Registrarse</button>
                <p>¿Ya tienes una cuenta? <a href="#" id="showLoginForm">Iniciar Sesión</a></p>
            </form>
        </div>
    </div>
    <script src="scripts.js"></script>
</body>
</html>
