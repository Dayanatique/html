document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('saveButton').addEventListener('click', function() {
        const formData = new FormData(document.getElementById('userForm'));

        fetch('save_user.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            alert(data);
            // Limpiar los campos del formulario después de guardar exitosamente
            document.getElementById('userForm').reset();
            document.getElementById('profileImage').src = './img/usu.png'; // Restaurar imagen por defecto
        })
        .catch(error => {
            console.error('Error:', error);
        });
    });

    // Mostrar la imagen seleccionada en el input
    document.getElementById('profilePicture').addEventListener('change', function(event) {
        const reader = new FileReader();
        reader.onload = function(){
            document.getElementById('profileImage').src = reader.result;
        }
        reader.readAsDataURL(event.target.files[0]);
    });

    document.querySelector('.photo-button').addEventListener('click', function() {
        document.getElementById('profilePicture').click();
    });
});
