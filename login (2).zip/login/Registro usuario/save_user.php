<?php
// Habilitar informes de errores
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Configuración de la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tb_usuarios";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Inicializar variables para campos del formulario
$nombre = '';
$apellido = '';
$telefono = '';
$documento = '';
$fotoPerfil ='';

// Verificar si el formulario fue enviado y los campos obligatorios están llenos
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = trim($_POST['nombre']);
    $apellido = trim($_POST['apellido']);
    $telefono = trim($_POST['telefono']);
    $documento = trim($_POST['documento']);
    $fotoPerfil = trim($_POST['profilePicture']);
    
    // Verificar campos obligatorios
    if (empty($nombre) || empty($apellido) || empty($documento)) {
        echo "Por favor, complete todos los campos obligatorios (Nombres, Apellidos, Documento).";
        exit;
    }
    
    // Verificar si el teléfono ha cambiado
    $telefono_actual = '';
    if (!empty($telefono)) {
        // Consultar el teléfono actual del usuario (si existe)
        $sql_select = "SELECT telefono FROM usuarios WHERE documento = ?";
        $stmt_select = $conn->prepare($sql_select);
        $stmt_select->bind_param("s", $documento);
        $stmt_select->execute();
        $stmt_select->bind_result($telefono_actual);
        $stmt_select->fetch();
        $stmt_select->close();
    }
    
    // Si el teléfono no ha cambiado, usar el teléfono actual
    if (empty($telefono)) {
        $telefono = $telefono_actual;
    }
    
    // Manejar la carga de la imagen
    $fotoPerfil = null;
    if (isset($_FILES['profilePicture']) && $_FILES['profilePicture']['error'] === UPLOAD_ERR_OK) {
        $fotoPerfil = 'uploads/' . basename($_FILES['profilePicture']['name']);
        move_uploaded_file($_FILES['profilePicture']['tmp_name'], $fotoPerfil);
    }

    // Insertar o actualizar los datos en la base de datos
    if (empty($telefono_actual)) {
        // Insertar nuevo usuario
        $sql = "INSERT INTO usuarios (nombre, apellido, telefono, documento, foto_perfil) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssss", $nombre, $apellido, $telefono, $documento, $fotoPerfil);
    } else {
        // Actualizar usuario existente
        $sql = "UPDATE usuarios SET nombre = ?, apellido = ?, telefono = ?, foto_perfil = ? WHERE documento = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssss", $nombre, $apellido, $telefono, $documento, $fotoPerfil);
    }

    if ($stmt->execute()) {
        echo "Usuario guardado exitosamente!";
        
        // Limpiar los campos después de guardar
        $nombre = '';
        $apellido = '';
        $telefono = '';
        $documento = '';
        $fotoPerfil = '';
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
