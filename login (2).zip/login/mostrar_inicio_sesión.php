<?php
include 'db_connection.php';
function OpenCon() {
    $dbhost = "localhost";
    $dbuser = "root";
    $dbpass = "";
    $db = "my_database";
    $conn = new mysqli($dbhost, $dbuser, $dbpass, $db) or die("Connect failed: %s\n". $conn -> error);
    return $conn;
}


// Conectar a la base de datos
$conn = OpenCon();
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


// Obtener los inicios de sesión
$sql = "SELECT is.id, u.username, is.hora_inicio 
        FROM inicios_sesion is
        JOIN users u ON is.usuario_id = u.id
        ORDER BY is.hora_inicio DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicios de Sesión</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h2>Inicios de Sesión</h2>
        <table>
            <tr>
                <th>ID</th>
                <th>Usuario</th>
                <th>Hora del Inicio</th>
            </tr>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row['id'] . "</td>";
                    echo "<td>" . $row['username'] . "</td>";
                    echo "<td>" . $row['hora_inicio'] . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='3'>No hay inicios de sesión registrados.</td></tr>";
            }
            ?>
        </table>
    </div>
</body>
</html>

<?php
$conn->close();

