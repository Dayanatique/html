document.getElementById('showRegisterForm').addEventListener('click', function() {
    document.getElementById('loginForm').classList.add('hidden');
    document.getElementById('registerForm').classList.remove('hidden');
});

document.getElementById('showLoginForm').addEventListener('click', function() {
    document.getElementById('registerForm').classList.add('hidden');
    document.getElementById('loginForm').classList.remove('hidden');
});

function togglePassword(inputId, toggleBtn) {
    const passwordInput = document.getElementById(inputId);
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        toggleBtn.textContent = 'Ocultar';
    } else {
        passwordInput.type = 'password';
        toggleBtn.textContent = 'Mostrar';
    }
}
