<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvenido</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Bienvenido, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
        <p><a href="mostrar_inicio_sesión.php">Ver Inicios de Sesión</a></p>
        <p><a href="logout.php">Cerrar Sesión</a></p>
    </div>
</body>
</html>
