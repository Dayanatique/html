const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const app = express();

// Middleware para manejar los datos del formulario
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Configuración de conexión a la base de datos MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '', // Asegúrate de usar la contraseña correcta para tu servidor MySQL
    database: 'tu_base_de_datos'
});

// Conectar a la base de datos
db.connect((err) => {
    if (err) {
        console.error('Error conectando a la base de datos:', err);
        return;
    }
    console.log('Conectado a la base de datos MySQL');
});

// Servir el archivo HTML para el formulario de registro
app.get('/register', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'registre.html'));
});

// Ruta para manejar el envío del formulario de registro
app.post('/register', (req, res) => {
    const { username, email, password } = req.body;

    // Validar los datos recibidos
    if (!username || !email || !password) {
        return res.status(400).send('Por favor, rellena todos los campos.');
    }

    // Consulta para insertar el nuevo usuario en la base de datos
    const insertQuery = 'INSERT INTO users (username, email, password) VALUES (?, ?, ?)';
    db.query(insertQuery, [username, email, password], (err, result) => {
        if (err) {
            console.error('Error al insertar el usuario:', err);
            return res.status(500).send('Error al registrar al usuario.');
        }

        // Enviar respuesta si se registra correctamente
        res.send('Usuario registrado con éxito.');
    });
});

// Iniciar el servidor en el puerto 3000
app.listen(3000, () => {
    console.log('Servidor corriendo en el puerto 3000');
});
