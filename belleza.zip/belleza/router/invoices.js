const express = require('express');
const router = express.Router();
const db = require('../db');
const PDFDocument = require('pdfkit');
const fs = require('fs');

// Generar y descargar PDF de la factura
router.get('/pdf/:invoice_id', (req, res) => {
    const { invoice_id } = req.params;

    const query = `
        SELECT i.id, i.total_amount, i.created_at, p.name, p.price, ip.quantity, (p.price * ip.quantity) AS total
        FROM invoices i
        JOIN invoice_products ip ON i.id = ip.invoice_id
        JOIN products p ON ip.product_id = p.id
        WHERE i.id = ?
    `;

    db.query(query, [invoice_id], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });

        const doc = new PDFDocument();
        let filename = `invoice_${invoice_id}.pdf`;
        let filePath = `./invoices/${filename}`;

        doc.pipe(fs.createWriteStream(filePath));

        // Título
        doc.fontSize(18).text('Factura', { align: 'center' });
        doc.moveDown();

        // Información de la factura
        doc.fontSize(14).text(`Factura ID: ${invoice_id}`);
        doc.text(`Fecha: ${results[0].created_at}`);
        doc.text(`Monto Total: $${results[0].total_amount}`);
        doc.moveDown();

        // Detalles de los productos
        results.forEach(item => {
            doc.text(`${item.name} - $${item.price} x ${item.quantity} = $${item.total}`);
        });

        doc.end();

        // Enviar el archivo PDF al cliente
        res.download(filePath, filename, (err) => {
            if (err) {
                res.status(500).json({ error: 'Error al descargar el archivo.' });
            } else {
                fs.unlink(filePath, (err) => {
                    if (err) console.error('Error al eliminar el archivo PDF:', err);
                });
            }
        });
    });
});

module.exports = router;
