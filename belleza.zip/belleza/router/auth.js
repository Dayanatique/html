router.post('/register', (req, res) => {
    const { username, email, password } = req.body;

    if (!username || !email || !password) {
        return res.status(400).json({ message: 'Todos los campos son requeridos.' });
    }

    // Verifica si el usuario ya existe
    const checkUserQuery = 'SELECT * FROM users WHERE email = ?';
    db.query(checkUserQuery, [email], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        if (result.length > 0) {
            return res.status(400).json({ message: 'El usuario ya existe.' });
        }

        // Inserta el nuevo usuario
        const insertUserQuery = 'INSERT INTO users (username, email, password) VALUES (?, ?, ?)';
        db.query(insertUserQuery, [username, email, password], (err, result) => {
            if (err) return res.status(500).json({ error: err.message });
            res.status(201).json({ message: 'Usuario registrado con éxito.' });
        });
    });
});
