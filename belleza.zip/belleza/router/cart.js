const express = require('express');
const router = express.Router();
const db = require('../db'); // Asegúrate de que tienes configurada la conexión a la base de datos

// Agregar producto al carrito
router.post('/add', (req, res) => {
    const { user_id, product_id, quantity } = req.body;

    // Verificar si el usuario ya tiene un carrito
    const findCartQuery = 'SELECT * FROM cart WHERE user_id = ?';
    db.query(findCartQuery, [user_id], (err, cartResult) => {
        if (err) return res.status(500).json({ error: err.message });

        let cart_id = cartResult.length ? cartResult[0].id : null;

        // Si no existe carrito, crearlo
        if (!cart_id) {
            const createCartQuery = 'INSERT INTO cart (user_id) VALUES (?)';
            db.query(createCartQuery, [user_id], (err, cartInsertResult) => {
                if (err) return res.status(500).json({ error: err.message });
                cart_id = cartInsertResult.insertId;
                addProductToCart(cart_id, product_id, quantity, res);
            });
        } else {
            addProductToCart(cart_id, product_id, quantity, res);
        }
    });
});

// Función para agregar producto al carrito
function addProductToCart(cart_id, product_id, quantity, res) {
    const checkProductQuery = 'SELECT * FROM cart_items WHERE cart_id = ? AND product_id = ?';
    db.query(checkProductQuery, [cart_id, product_id], (err, cartItemResult) => {
        if (err) return res.status(500).json({ error: err.message });

        if (cartItemResult.length) {
            // Si el producto ya está en el carrito, actualizar la cantidad
            const updateQuantityQuery = 'UPDATE cart_items SET quantity = quantity + ? WHERE cart_id = ? AND product_id = ?';
            db.query(updateQuantityQuery, [quantity, cart_id, product_id], (err) => {
                if (err) return res.status(500).json({ error: err.message });
                res.json({ message: 'Cantidad del producto actualizada en el carrito.' });
            });
        } else {
            // Si el producto no está en el carrito, añadirlo
            const insertProductQuery = 'INSERT INTO cart_items (cart_id, product_id, quantity) VALUES (?, ?, ?)';
            db.query(insertProductQuery, [cart_id, product_id, quantity], (err) => {
                if (err) return res.status(500).json({ error: err.message });
                res.json({ message: 'Producto agregado al carrito.' });
            });
        }
    });
}

module.exports = router;
